**NOTICE**
1.BSP and Driver package is compatible Ver3.7.0 and higher version.
Please check your BSP and Driver version.

2. At the evaluation version library, OpenGL and H.264 codec library are limited at execution time, These libraries will stop drawing after running 3 hours. If you see the log like; "Warning: This limited SGX library EXPIRED on your platform now.", You need to reboot your board.
